package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int[] oddNumbers=new int[5];

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        int i;

        for(i=0;i<5;i++) {
            oddNumbers[i] = sc.nextInt();
        }

        System.out.println("The result is");

        for(i=0;i<5;i++) {

            if (oddNumbers[i] % 2 != 0) {
                System.out.println(oddNumbers[i]);
            }

        }

    }
}
