package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int[] sum=new int[5];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the numbers");

        int i;
        for(i=0;i<5;i++) {

            sum[i] = sc.nextInt();
            sum[i] = sum[0] + sum[1] + sum[2] + sum[3] + sum[4];
            System.out.println("The sum of the numbers is " + sum[i]);

        }

    }
}
