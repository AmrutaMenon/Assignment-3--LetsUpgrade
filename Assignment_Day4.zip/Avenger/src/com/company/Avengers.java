package com.company;

import java.util.Scanner;

public class Avengers {

        Scanner sc=new Scanner(System.in);

        public String name;
        public int age;
        public String power;
        public String weapon;
        public String planet;

        public void getDetails(){

            System.out.println("Name:");
            name=sc.nextLine();

            System.out.println("Age:");
            age=sc.nextInt();
            sc.nextLine();

            System.out.println("Power:");
            power=sc.nextLine();

            System.out.println("Weapon:");
            weapon=sc.nextLine();

            System.out.println("Planet:");
            planet=sc.nextLine();

        }

        public void displayDetails(){

            System.out.println("Avenger name is " +name + "\nAvenger age is " +age + "\nAvenger power is " +power + "\nAvenger weapon is " +weapon + "\nAvenger planet is " +planet);

        }
}
